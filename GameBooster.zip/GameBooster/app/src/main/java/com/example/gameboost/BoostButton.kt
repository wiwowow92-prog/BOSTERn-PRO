package com.example.gameboost

import android.content.Context
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.animation.OvershootInterpolator
import androidx.appcompat.widget.AppCompatTextView

/** Tombol BOOST gaya iOS: pil besar, tanpa animasi loop (hemat CPU/GPU saat main game). */
class BoostButton @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    AppCompatTextView(context, attrs) {

    private val h = Handler(Looper.getMainLooper())
    private val idle = Runnable { setIdle() }

    init {
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        letterSpacing = 0.08f
        textSize = 17f
        setTextColor(0xFFFFFFFF.toInt())
        isClickable = true
        setIdle()
    }

    private fun setIdle() { setBackgroundResource(R.drawable.bg_boost); text = "⚡  BOOST" ; isEnabled = true }

    fun start() { h.removeCallbacks(idle); setBackgroundResource(R.drawable.bg_boost); text = "Membersihkan…"; alpha = 0.75f }

    fun finish(result: String) {
        alpha = 1f
        setBackgroundResource(R.drawable.bg_boost_done)
        text = "✓  $result"
        h.removeCallbacks(idle); h.postDelayed(idle, 2200)
    }

    override fun onDetachedFromWindow() { h.removeCallbacks(idle); super.onDetachedFromWindow() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
        }
        return super.onTouchEvent(e)
    }
}
